package comboAppTests;

import lib.BaseClass;
import lib.CommonExcel;
import lib.ComboAppData;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;


import comboAppPages.VendorCreationPage;
import comboAppPages.WoCreationpage;
import comboAppPages.ClientCreation;
import comboAppPages.CreateCrewCreationPage;
import comboAppPages.InvoiceCreationPage;
import comboAppPages.LoginPage;
import comboAppPages.NewCompanyCreationPage;
import comboAppPages.NewRoleCreationPage;
import comboAppPages.NewTradeCreationPage;
import comboAppPages.ProposalCreationPage;
import comboAppPages.PurchaseOrderCreationPage;
import comboAppPages.SiteCreationPage;
import comboAppPages.TeamMemberCreationPage;
import comboAppPages.TradesmanCreationPage;
//import comboAppPages.MainPage;





public class ComboAppTest extends BaseClass
{
	public static Logger log = LogManager.getLogger(ComboAppTest.class);
	
	@Test(dataProvider="getdata", dataProviderClass=CommonExcel.class)
	public void ulipKotakTest(final int iTestCaseID, ComboAppData testData) throws Exception 
	{
		long tmStart = 0, tmEnd = 0;
		try 
		{ 
			tmStart = System.nanoTime();	
			
			log.info("@@@@@Start Test:" + iTestCaseID);
			log.debug("Test Data:" + testData);
			
					
			
			LoginPage mPage = new LoginPage();
			mPage.fnHomePage(iTestCaseID, testData);
			
			NewRoleCreationPage Newrolecreatpage= new NewRoleCreationPage();
			Newrolecreatpage.fnNewRoleCreation(iTestCaseID, testData);
			
			
			NewTradeCreationPage Tradereationpage= new NewTradeCreationPage();
			Tradereationpage.fnTradesCreation(iTestCaseID, testData);
									
			//TeamMemberCreationPage TeMemcreationPage=new TeamMemberCreationPage();
			//TeMemcreationPage.fnTeamMemeberCreation(iTestCaseID, testData);
			//TeMemcreationPage.fnNewTeamMemberCreation(iTestCaseID, testData);
			
			TradesmanCreationPage TradesmanCratPage=new TradesmanCreationPage();
			TradesmanCratPage.fnTradesmanCreation(iTestCaseID, testData);
			
			CreateCrewCreationPage Crewcreationpage= new CreateCrewCreationPage();
			Crewcreationpage.fnCrewCreation(iTestCaseID, testData);
			
			//NewTradeCreationPage Tradereationpage= new NewTradeCreationPage();
			//Tradereationpage.fnTradesCreation(iTestCaseID, testData);
							
			
			ClientCreation CCreationPage = new ClientCreation();			
			CCreationPage.fnClientCreation(iTestCaseID, testData);
			
			//NewCompanyCreationPage NCmpcreationpage= new NewCompanyCreationPage();
			//NCmpcreationpage.fnCompanyCreation(iTestCaseID, testData);

			
			VendorCreationPage vcpage = new VendorCreationPage();
			vcpage.fnVendorCreation(iTestCaseID, testData);
			
		//	NewCompanyCreationPage NCmpcreationpage= new NewCompanyCreationPage();
		//	NCmpcreationpage.fnCompanyCreation(iTestCaseID, testData);
			
			//NewRoleCreationPage Newrolecreatpage= new NewRoleCreationPage();
			//Newrolecreatpage.fnNewRoleCreation(iTestCaseID, testData);
			
			
			//TeamMemberCreationPage TeMemcreationPage=new TeamMemberCreationPage();
			//TeMemcreationPage.fnTeamMemeberCreation(iTestCaseID, testData);
			//TeMemcreationPage.fnNewTeamMemberCreation(iTestCaseID, testData);
			
			//TradesmanCreationPage TradesmanCratPage=new TradesmanCreationPage();
			//TradesmanCratPage.fnTradesmanCreation(iTestCaseID, testData);
			
			//CreateCrewCreationPage Crewcreationpage= new CreateCrewCreationPage();
			//Crewcreationpage.fnCrewCreation(iTestCaseID, testData);
			
			//WoCreationpage wordPage = new WoCreationpage();
			//wordPage.fnworkordcreation(iTestCaseID, testData);
				
			//calender module work order
			
		//	ProposalCreationPage Pcreationpage=new ProposalCreationPage();
		//	Pcreationpage.fnProposalCreation(iTestCaseID, testData);			
			
			
			PurchaseOrderCreationPage PurOrdcreationpage= new PurchaseOrderCreationPage();
			PurOrdcreationpage.fnPurchaseOrderCreation(iTestCaseID, testData);
			
			//InvoiceCreationPage Invcpage= new InvoiceCreationPage();
			//Invcpage.fnInvoiceCreation(iTestCaseID, testData);
								
			

			//NewCompanyCreationPage NCmpcreationpage= new NewCompanyCreationPage();
			//NCmpcreationpage.fnCompanyCreation(iTestCaseID, testData);
				
			
			
			//VendorCreationPage vcpage = new VendorCreationPage();
			//vcpage.fnVendorCreation(iTestCaseID, testData);
			
			//ClientCreation newClient = new ClientCreation();
			//newClient.fnClientCreation(iTestCaseID, testData);
			
		//	SiteCreationPage SiteCreation= new SiteCreationPage();
		//	SiteCreation.fnSiteCreation(iTestCaseID, testData);
			
			 		
					
			 	
			log.info("@@@@@End Test:" + iTestCaseID);
			
		}
		// Catch exceptions on the complete test 
		catch (Exception ex) 
		{
			log.error("------************************************------");
			log.error("@@@@@Failed Test:" + iTestCaseID);
			log.error(getStackTrace(ex));
			log.error("------********Data Start******************------");
			log.error("Test Data:" + testData);
			log.error("------********Data End********************------");

			vTakeImage("Error.TCID-"+iTestCaseID);
			
			
			throw ex;
		}
		/*finally
		{
			tmEnd= System.nanoTime();
			log.debug("Total Time for Execution : " + ((tmEnd-tmStart)/(1000*1000)) + " msecs");
		}*/
	}
}
