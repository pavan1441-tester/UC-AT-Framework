package comboAppPages;
import lib.ComboAppData;
import lib.CommonClass;
import net.bytebuddy.asm.Advice.Enter;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
//import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddNewSerivceandTaskPage extends ComboAppBasePage
{

	public AddNewSerivceandTaskPage()
	{
		super();
	}
	
	//Click Main menu slide
	@FindBy(css=".fa-plus")
	private WebElement clickOnMainMenu;

	//click on Services Module    
	@FindBy(css="#services > .dropdown-toggle")
	private WebElement clickOnServicesModule;

	//click on Service Section
	@FindBy(css="#trade_services .sidenav-text")
	private WebElement clickOnServiceSection;

	//click on New Service button    
	@FindBy(linkText ="NEW SERVICE")
	private WebElement clickOnNewService;

	//Click On Select Trade Name
	@FindBy(css=".select2-container--below .select2-selection")
	private WebElement tradeNameClick;



	//Enter Trade Name
	@FindBy(xpath="//input[@type='search']")
	private WebElement enterName; //control +enter sendkeys

	//Enter Service Name
	@FindBy(xpath="//input[@id='trade_service_name']")
	private WebElement enterServiceName;

	//Enter Service Description
	@FindBy(xpath="//textarea[@id='trade_service_description']")
	private WebElement enterDescription;

	//Click on Create New Task link
	@FindBy(linkText="Create New Task")
	private WebElement createNewTask;

	//ENter Task Name
	@FindBy(xpath="//input[@id='task_name']")
	private WebElement taskName;



	//Enter Cost Code
	@FindBy(xpath="//input[@id='task_cost_code']")
	private WebElement costCode;

	//Click On Save Button
	@FindBy(xpath="(//input[@name='commit'])[2]")
	private WebElement clickTaskSaveButton;

	//Select Newly added Task 
	@FindBy(xpath="//li[contains(.,'Pipe Task')]")
	private WebElement selectNewlyAddedTask;

	@FindBy(xpath="//input[@name='commit']")
	private WebElement clickServiceSaveButton;

	//Add new Functions
	public void fnServiceCreation(int iTestCaseID, ComboAppData testData) throws Exception
	{
	waitForThread(CommonClass.iWaitForThread1);
	clickOnMainMenu.click();
	waitForThread(CommonClass.iWaitForThread1);

	waitForThread(CommonClass.iWaitForThread1);
	clickOnServicesModule.click();
	waitForThread(CommonClass.iWaitForThread1);

	waitForThread(CommonClass.iWaitForThread1);
	clickOnServiceSection.click();
	waitForThread(CommonClass.iWaitForThread1);

	waitForThread(CommonClass.iWaitForThread1);
	clickOnNewService.click();
	waitForThread(CommonClass.iWaitForThread1);

	waitForThread(CommonClass.iWaitForThread1);
	tradeNameClick.click();
	waitForThread(CommonClass.iWaitForThread1);

	sendValue(enterName,"drainage Pipes","Enter Trade Name");

	waitForThread(CommonClass.iWaitForThread1);
	sendValue(enterName,"control+enter key","Enter Trade Name");

	waitForThread(CommonClass.iWaitForThread1);
	sendValue(enterServiceName,"Pipe Maintainance","Enter SIC Code");

	waitForThread(CommonClass.iWaitForThread1);
	sendValue(enterDescription,"Service Added by automation","Enter Description");

	waitForThread(CommonClass.iWaitForThread1);
	createNewTask.click();
	waitForThread(CommonClass.iWaitForThread1);

	//sendValue(taskName,"Pipe Task","Enter Task Name");

	waitForThread(CommonClass.iWaitForThread1);
	sendValue(costCode,"500","Enter Cost Code");

	waitForThread(CommonClass.iWaitForThread1);
	clickTaskSaveButton.click();
	waitForThread(CommonClass.iWaitForThread1);

	waitForThread(CommonClass.iWaitForThread1);
	selectNewlyAddedTask.click();
	waitForThread(CommonClass.iWaitForThread1);

	waitForThread(CommonClass.iWaitForThread1);
	clickServiceSaveButton.click();
	waitForThread(CommonClass.iWaitForThread1);


	}


}
