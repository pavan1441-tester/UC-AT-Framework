package comboAppPages;


import lib.ComboAppData;
import lib.CommonClass;
import net.bytebuddy.asm.Advice.Enter;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
//import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class VendorCreationPage extends ComboAppBasePage 
{
	public VendorCreationPage() 
	{
	super();
    }

   //client option select
	@FindBy(xpath="//*[@id='clients']/a/div[1]/i")	
  private WebElement weClientopt;
	
	//popup close
	@FindBy(xpath="//*[@id='Embed']/div/div/div/div/div/div/div[1]/div/button[2]")
	 private WebElement wepopup;

	@FindBy(xpath="//*[@id='webWidget']")
    private WebElement wepopupframe;

	

	   //vendor option select
		@FindBy(xpath="//div[@id='client-list-holder']/div[@class='container-fluid p0']//div[@class='col-sm-5 mb3']/a[@role='tab']/i[@class='fa fa-hard-hat']")	
	  private WebElement weVendoropt;
		

		@FindBy(xpath="//*[@id='page-content']/a")
	     private WebElement weVensoroptPlus;
		
	@FindBy(xpath="//div[@id='page-content']/div[@class='main-page']/div/div[@class='row']/div[@class='col-sm-10 col-sm-offset-1']//a[@href='/company/wizard/contractors/new']")
	     private WebElement weCreateNewVendor;
	
	//*[@id="company_name"]
	@FindBy(xpath="//input[@id='company_name']")
    private WebElement weVcompanyName;

	@FindBy(xpath="//input[@id='company_legal_address_attributes_formatted_address']")
    private WebElement weVcompanyAddress;
	
	//@FindBy(xpath="//input[@id='company_legal_address_attributes_formatted_address']")
  //  private WebElement weVcompanyAddress;



	//*[@id="company_legal_address_attributes_address1"]
	@FindBy(xpath="//input[@id='company_legal_address_attributes_address1']")
    private WebElement weVcompanyAddress1;


	//*[@id="company_legal_address_attributes_city"]
	@FindBy(xpath="//input[@id='company_legal_address_attributes_city']")
    private WebElement weVcompanyCityDetais;

	//*[@id="company_legal_address_attributes_state"]
	@FindBy(xpath="//input[@id='company_legal_address_attributes_state']")
    private WebElement weVcompanyStateDetais;


	//*[@id="company_legal_address_attributes_zip_code"]
	@FindBy(xpath="//input[@id='company_legal_address_attributes_zip_code']")
    private WebElement weVcompanyZipcodeDetails;

	//*[@id="company_email"]
	@FindBy(xpath="//input[@id='company_email']")
    private WebElement weVcompanyEmailDetails;
	
	//*[@id="company_phone"]
	@FindBy(xpath="//input[@id='company_phone']")
    private WebElement weVcompanyPhoneNoDetails;
	

	//*[@id="company_extension"]
	@FindBy(xpath="//input[@id='company_extension']")
    private WebElement weVcompanyExtensionDetails;
	
	//*[@id="company_website"]
	@FindBy(xpath="//input[@id='company_website']")
    private WebElement weVcompanyWebsiteDetails;
	

	//*[@id="company_vendor_number"]
	@FindBy(xpath="//input[@id='company_vendor_number']")
    private WebElement weVcompanyVendorNoDetails;
	

	//*[@id="company_description"]
	//*[@id="company_description"]
	@FindBy(xpath="//*[@id='company_description']")
    private WebElement weVcompanyDescriptionDetails;
	

	//*[@id="company_vendor_coins_connection_attributes_external_id"]
		@FindBy(xpath="//input[@id='company_vendor_coins_connection_attributes_external_id']")
        private WebElement weVcompanyCoinsDetails;
	
		
		@FindBy(xpath="//form[@id='new_company']/div[1]//label/i[@class='fa fa-upload']")
        private WebElement weVcompanyUploadLogo;
	

		//Continue button
		@FindBy(xpath="//input[@value='NEXT' and @type='submit']")	
		 private WebElement weBtnNEXT;
		
		
		//Tab 2 Company Administration
		
		@FindBy(xpath="//input[@id='company_contacts_attributes_0_first_name']")
        private WebElement weVAdminFirstName;
		

		//*[@id="company_contacts_attributes_0_last_name"]
		@FindBy(xpath="//input[@id='company_contacts_attributes_0_last_name']")
        private WebElement weVAdminLastName;
		

		//*[@id="company_contacts_attributes_0_title"]
		@FindBy(xpath="//input[@id='company_contacts_attributes_0_title']")
        private WebElement weVAdminTitle;
		
		//*[@id="company_contacts_attributes_0_email"]
		@FindBy(xpath="//input[@id='company_contacts_attributes_0_email']")
        private WebElement weVAdminEmail;

		//*[@id="company_contacts_attributes_0_phone"]
		@FindBy(xpath="//input[@id='company_contacts_attributes_0_phone']")
        private WebElement weVAdminPhone;
		
		//*[@id="company_contacts_attributes_0_mobile"]
		@FindBy(xpath="//input[@id='company_contacts_attributes_0_mobile']")
        private WebElement weVAdminMobile;
		
	
	//div[@id='client-list-holder']//i[@safeclass~'\bfa\b.*\bfa-hard-hat\b']
		//*[@id="page-content"]/a/i
		
		//3rd Tab
		
		//@FindBy(xpath="//*[@id='company_company_services']")
		//span[@class='amountCharged']
		//@FindBy(xpath="//*[@id='select2-selection select2-selection--multiple']")
		@FindBy(xpath="/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div/form/div[1]/div[2]/div[1]/div/span/span[1]/span/ul")
		//*[@id="edit_company_133054
		 private WebElement weCompanyservice;

		
	
		@FindBy(xpath="//ul[@id='select2-company_company_services-results']/li[1]")
		 private WebElement weCompanyserviceselctn;
		//Material Supplier
		
		@FindBy(xpath="//*[@id='company_restricted_note']")				
		 private WebElement weCompanyNotes;
		                
		//@FindBy(xpath="//*[@id='select2-company_one_time_only-container']")
		//*[@id="edit_company_133062"]/div[1]/div[2]/div[3]/div/span/span[1]/span/span[2]
		@FindBy(xpath="//span[@id='select2-company_one_time_only-container']/span[@class='select2-selection__placeholder']")
		 private WebElement weConatiner;
		
		@FindBy(xpath="//ul[@id='select2-company_one_time_only-results']/li[1]")				
		 private WebElement weConatinersel;
		
		
		@FindBy(xpath="//*[@id='company_recruiter']")		
		 private WebElement weCompnyrecuirt;
				
		
		@FindBy(xpath="//*[@id='company_comments']")		
		 private WebElement weCompnycoments;
				

		@FindBy(xpath="//*[@id='company_wo_message']")		
		 private WebElement weCompnywomessage;
		
		//Tab-4
		//Payment
		
		@FindBy(xpath="//*[@id='company_payment_term_attributes_net_days']")		
		 private WebElement wePaymentnetdays;
		
		
		
		@FindBy(xpath="//*[@id='company_payment_term_attributes_term_discount_days']")		
		 private WebElement wePaymentDiscountdays;
				
		//@FindBy(xpath="//*[@id='/html/body/div[1]/div[1]/div[3]/div/div/div/div/div/div/form/div[1]/div[2]/div[4]/div/div[2]/div/span/span[1]/span']")	
		@FindBy(xpath="//*[starts-with(@id,'edit_company_')]")
		 private WebElement wePaymentTerms;
		
		
		//@FindBy(xpath="//body/span/span[@class='select2-dropdown select2-dropdown—below']//ul[@role='listbox']/li[3]")	
		//@FindBy(xpath="//*[@id='select2-company_payment_term_attributes_terms-result- -COD']")
		//*[@id="select2-company_payment_term_attributes_terms-result-zy0n-COD"]
		 //private WebElement wePaymentTermsSel;
		
			
		@FindBy(xpath="//*[@id='company_payment_term_attributes_term_discount']")		
		 private WebElement wePayTermDiscount;
		
		//Tab-5

				@FindBy(xpath="//*[@id='company_termination_attributes_re_date']")						
				 private WebElement WebElementReactDate;
				
				
				@FindBy(xpath="//*[@id='company_termination_attributes_reactivation_date']")						
				 private WebElement WebElementReactDateTime;
				
				
				@FindBy(xpath="//*[@id='company_termination_attributes_te_date']")						
				 private WebElement WebElementTerminatnDate;
				
				
				@FindBy(xpath="//*[@id='company_termination_attributes_termination_date']")						
				 private WebElement WebElementTerminatnDateTime;
				
				
				@FindBy(xpath="//*[@id='company_termination_attributes_terminated_by']")						
				 private WebElement WebElementTerminatedBy;
				
				
				
				@FindBy(xpath="//*[@id='company_termination_attributes_reason']")						
				 private WebElement WebElementTerminateReason;
				
				//Tab-6
				
				@FindBy(xpath="//*[@id='vendor-service-rates']/div/div/div/table/tfoot/tr[2]/td/div/a")											
				 private WebElement WebElementAddservice;
				
				
				//@FindBy(xpath="//div[@id='assign_services_modal']/div[@class='modal-dialog']//h4[@class='modal-title']")		
				@FindBy(xpath="//*[@id='assign_services_modal']")
				 private WebElement WebElementserviceModelpopoup;
				
				//*[@id="select2-service_rate_trade_service_id-container"]
				@FindBy(xpath="//*[@id='select2-service_rate_trade_service_id-container']")											
				 private WebElement WebElementservicename;
				
				//*[@id="select2-service_rate_trade_service_id-results"]/li[2]
				@FindBy(xpath="//*[@id='select2-service_rate_trade_service_id-results']/li[2]")											
				 private WebElement WebElementserviceSelctn;
				
				
				@FindBy(xpath="//*[@id='service_rate_client_rate']")
				 private WebElement WebElementserClienteRate;
				
				

				@FindBy(xpath="//*[@id='service_rate_client_pm_rate']")
				 private WebElement WebElementserClientePMRate;
				
				

				@FindBy(xpath="//*[@id='service_rate_vendor_rate']")
				 private WebElement WebElementserVendorRate;
				
				
				@FindBy(xpath="//*[@id='service_rate_vendor_pm_rate']")
				 private WebElement WebElementserVendorPMRate;
				
				
				//Save button
				@FindBy(xpath="//input[@value='SAVE' and @type='submit']")	
				 private WebElement weBtnSAVE;
				
				

				//Next Link 
				@FindBy(xpath="//a[text()='NEXT']")	
				 private WebElement weLinkNEXT;
				
				@FindBy(xpath="//*[@id='private_regions_list']/div/h1/a")	
				 private WebElement weregionlist;
				
				@FindBy(xpath="//div[@id='contractor_regions']/ul/li[2]/a/i[1]")	
				 private WebElement weTradelists;
				
				
				
				@FindBy(xpath="//form[@id='contractor_region']/div[@class='row']//a[@href='#']")	
				 private WebElement weSavebtn;
						

		public void fnVendorCreation(int iTestCaseID, ComboAppData testData) throws Exception
		{
			// TODO Auto-generated method stub
			CommonClass.driver.navigate().refresh();
			WebDriverWait Tripbtn = new WebDriverWait(CommonClass.driver, 20);

			//waitForThread(CommonClass.iWaitForThread2);

			weClientopt.click();
			waitForThread(CommonClass.iWaitForThread1);
			
			/*CommonClass.driver.switchTo().frame(wepopupframe);	
		    System.out.println("iframe switch properly");
			Actions actions6 = new Actions(CommonClass.driver); 
	       actions6.moveToElement(wepopup).click().perform();*/

			weVendoropt.click();

			waitForThread(CommonClass.iWaitForThread2);
			//waitForThread(CommonClass.iWaitForThread1);
			
			
			//if(wepopupframe.isDisplayed()== true)
				 if(!CommonClass.driver.findElements(By.xpath("//*[@id='webWidget']")).isEmpty())
				 {
	
		         System.out.println("frame Unable");

			    CommonClass.driver.switchTo().frame(wepopupframe);	
				
				System.out.println("iframe switch properly");
				Actions actions6 = new Actions(CommonClass.driver); 
		        actions6.moveToElement(wepopup).click().perform();
		      }
	           else
	            {
	            	System.out.println("frame disable");
	            	
	          }
			
			weVensoroptPlus.click();
			waitForThread(CommonClass.iWaitForThread1);

			weCreateNewVendor.click();

			//new comapny
		
			//sendValue(weVcompanyName,"RV_Test20212912","Enter the New comapny Name");			
			waitForThread(CommonClass.iWaitForThread);
			String Vendorname = "RV_Test212807" + new Random().nextInt(1000);
			CommonClass.driver.findElement(By.id("company_name")).sendKeys(Vendorname);
			
			
			//sendValue(weVcompanyAddress,"Gdańsk, Poland","Enter the Company Address");
			//waitForThread(CommonClass.iWaitForThread1);
			
			//WebElement Bil = CommonClass.driver.findElement(By.id("location_billing_address_attributes_formatted_address")); //Google API billing address
			waitForThread(CommonClass.iWaitForThread);

			weVcompanyAddress.sendKeys("Gdańsk, Poland"); //api address
			
			//Thread.sleep(2000L);
			waitForThread(CommonClass.iWaitForThread);

			
			weVcompanyAddress.sendKeys(Keys.DOWN);
			//Thread.sleep(2000L);
			waitForThread(CommonClass.iWaitForThread);

			weVcompanyAddress.sendKeys(Keys.ENTER);
			
	       // Select drpdwn = new Select(CommonClass.driver.findElement(By.id("company_legal_address_attributes_formatted_address")));
	       // drpdwn.selectByVisibleText("Gdańsk, Poland");

			waitForThread(CommonClass.iWaitForThread2);

			sendValue(weVcompanyAddress1,"9889 Floin Rd, Sacramento, CA 95889, USA","Enter the Company Address1");
			waitForThread(CommonClass.iWaitForThread2);


			//sendValue(weVcompanyCityDetais,"9879 Florin Road","Enter the City Details");

			//sendValue(weVcompanyStateDetais,"CA","Enter the State Details");

			sendValue(weVcompanyZipcodeDetails,"96849","Enter the Zipcode Details");
			
			sendValue(weVcompanyEmailDetails,"harishpatil+11@utilizecore.com","Enter the Email Details");


			sendValue(weVcompanyPhoneNoDetails,"+1 222 555 7787","Enter the PhoneNo Details");
			//sendValue(weVcompanyExtensionDetails,"00","Enter the Extesion Details");
			//sendValue(weVcompanyWebsiteDetails,"www.regression.com","Enter the Website Details");
			sendValue(weVcompanyVendorNoDetails,"11111","Enter the vendorNo Details");
			sendValue(weVcompanyDescriptionDetails,"For the REgresstion Test Description","Enter the Description Details");
			
			//sendValue(weVcompanyCoinsDetails,"test210712","Enter the Coins Details");
			String CoinDetils = "RV_Test2807" + new Random().nextInt(1000);
			CommonClass.driver.findElement(By.id("company_vendor_coins_connection_attributes_external_id")).sendKeys(CoinDetils);
			
			waitForThread(CommonClass.iWaitForThread1);

			
			/*weVcompanyUploadLogo.click();
			waitForThread(CommonClass.iWaitForThread1);
			weVcompanyUploadLogo.sendKeys("//home//harish//Desktop//logo");
			waitForThread(CommonClass.iWaitForThread1);
   			System.out.println("LOgo Uploaded Successfully");*/
			
			weBtnNEXT.click();
   			System.out.println("Next button Successfully done");
			waitForThread(CommonClass.iWaitForThread2);
			waitForThread(CommonClass.iWaitForThread1);

			sendValue(weVAdminFirstName,"RtestFame1","Enter the Admin First name");

			sendValue(weVAdminLastName,"RtestLame1","Enter the Admin Last name");

			sendValue(weVAdminTitle,"Mr","Enter the Admin Titles");

			sendValue(weVAdminEmail,"test@test.com","Enter the Admin Email Details");

		    sendValue(weVAdminPhone,"+3 555 888 88888","Enter the Admin Phone Details");

		   
		    sendValue(weVAdminMobile,"5558885555","Enter the Admin Phone Details");
		    
		    weBtnNEXT.click();
			waitForThread(CommonClass.iWaitForThread1);
			
			//Tab 3rd
			
			weCompanyservice.click();
			waitForThread(CommonClass.iWaitForThread1);
			
			weCompanyserviceselctn.click();
			
			
			//weCompanyserviweCompanyNotes;
		    sendValue(weCompanyNotes,"tstnotes","Enter the Admin Phone Details");

			
		    weConatiner.click();
			waitForThread(CommonClass.iWaitForThread);
			
		    weConatinersel.click();
			
			waitForThread(CommonClass.iWaitForThread1);
			
			
			
	       sendValue(weCompnyrecuirt,"Test Recuiter","Enter the Recruciter Details");
	
			
		
		    sendValue(weCompnycoments,"TestComents","Enter the Comment Details");

			

			
		    sendValue(weCompnywomessage,"Test Message","Enter the message Details");
		   
			waitForThread(CommonClass.iWaitForThread1);
			

		    weBtnNEXT.click();
			waitForThread(CommonClass.iWaitForThread1);
			
			
			//Tab 4 Payment
			
		
		    sendValue(wePaymentnetdays,"45","Enter the net payment Details");

		    sendValue(wePaymentDiscountdays,"45","Enter the Discount payment Details");

			waitForThread(CommonClass.iWaitForThread1);

		   // wePaymentTerms.click();
			//waitForThread(CommonClass.iWaitForThread1);
	
			
		   // wePaymentTermsSel.click();
			
			waitForThread(CommonClass.iWaitForThread1);

			
		    sendValue(wePayTermDiscount,"10","Enter the Discount term");

		    weBtnNEXT.click();
			waitForThread(CommonClass.iWaitForThread1);
			
	//Tab5 Deactivation
			
			
			/*WebElementReactDate.clear();
			waitForThread(CommonClass.iWaitForThread1);
			WebElementReactDate.sendKeys("07/19/2021");
			
		
			WebElementReactDateTime.clear();
			waitForThread(CommonClass.iWaitForThread1);
			WebElementReactDateTime.sendKeys("5:53 PM");
			
			
			WebElementTerminatnDate.clear();
			waitForThread(CommonClass.iWaitForThread1);
			WebElementTerminatnDate.sendKeys("07/19/2022");
			
		
			WebElementTerminatnDateTime.clear();
			waitForThread(CommonClass.iWaitForThread1);
			WebElementTerminatnDateTime.sendKeys("5:53 PM");
		
								
			
		    sendValue(WebElementTerminatedBy,"Harish","Enter the terminated term");

		    sendValue(WebElementTerminateReason,"TestingPurpose","Enter the terminated Purpose");*/

			
					
			 weBtnNEXT.click();
				waitForThread(CommonClass.iWaitForThread1);
				
			
				//Tab6
				
				WebElementAddservice.click();
				waitForThread(CommonClass.iWaitForThread);
			//	CommonClass.driver.switchTo().frame(WebElementserviceModelpopoup);
				CommonClass.driver.switchTo().activeElement();
				//CommonClass.driver.switchTo().frame(wepopupframe);	
				//*[@id="webWidget"]
				System.out.println("Active element switch properly");
				waitForThread(CommonClass.iWaitForThread);
				Actions actions6 = new Actions(CommonClass.driver); 
		        actions6.moveToElement(WebElementserviceModelpopoup).click().perform();
				System.out.println("Active element click properly");

		    	waitForThread(CommonClass.iWaitForThread);
				WebElementservicename.click();
		    	waitForThread(CommonClass.iWaitForThread);

				WebElementserviceSelctn.click();
				
		    	waitForThread(CommonClass.iWaitForThread);

			    sendValue(WebElementserClienteRate,"100","Enter the Client Rate");
			    sendValue(WebElementserClientePMRate,"250","Enter the Client  PM Rate");
			    sendValue(WebElementserVendorRate,"125","Enter the vendor Rate");
		    	waitForThread(CommonClass.iWaitForThread);
			    sendValue(WebElementserVendorPMRate,"275","Enter the Vendor PM Rate");

		    	waitForThread(CommonClass.iWaitForThread);
		
				//Save button
		    	
		    	weBtnSAVE.click();
				waitForThread(CommonClass.iWaitForThread1);

		    	// weBtnNEXT.click();
		    	 weLinkNEXT.click();
					waitForThread(CommonClass.iWaitForThread1);
				

                   //TAB7
					waitForThread(CommonClass.iWaitForThread1);

					 weBtnNEXT.click();
					 
						waitForThread(CommonClass.iWaitForThread1);
					
				      //TAB-8
						waitForThread(CommonClass.iWaitForThread1);

						 weBtnNEXT.click();
							waitForThread(CommonClass.iWaitForThread2);
							
							weregionlist.click();
							waitForThread(CommonClass.iWaitForThread);
							
							Actions actions7 = new Actions(CommonClass.driver); 
					        actions7.moveToElement(weTradelists).click().perform();
							System.out.println("Active States click properly");
							waitForThread(CommonClass.iWaitForThread);
							weSavebtn.click();
							waitForThread(CommonClass.iWaitForThread);
							 weBtnNEXT.click();
							 waitForThread(CommonClass.iWaitForThread2);
		}
		
		


}
